# Neema Home Care: Website

A static marketing website (HTML, CSS, vanilla JavaScript). No build tools, frameworks or backend.

## Open it locally
Double-click `index.html`, or serve the folder:

```
python -m http.server 8080     # then visit http://localhost:8080
```

All paths are relative, so the site works from any folder or static host.

## Deploy
- **Netlify:** drag the `neema-home-care` folder onto app.netlify.com/drop (or connect a repo; no build command, publish directory `/`). Netlify serves `404.html` automatically.
- **GitHub Pages:** push the folder contents to a repo, then Settings > Pages > deploy from branch. GitHub Pages serves `404.html` automatically.
- **Any static host (cPanel, S3, Hostinger, etc.):** upload the folder contents to the web root.

Note: `404.html` uses relative asset paths. If your host serves it for deep URLs (e.g. `/a/b/c`), styles may not load; in that case change the asset links in `404.html` to start with `/`.

## Placeholder checklist (replace before launch)
- [ ] **Domain:** replace `https://www.example.com` in every page's `<link rel="canonical">` and `og:url`/`og:image`, in `sitemap.xml` and in `robots.txt`.
- [ ] **Logo:** `assets/images/logo.svg` (header, dark text) and `assets/images/logo-light.svg` (footer). Keep the same file names, or search/replace. Logo text uses Georgia as a fallback; for a final logo, convert text to outlines.
- [ ] **Favicon:** `assets/images/favicon.svg` (add PNG/ICO versions if needed for older browsers).
- [ ] **Social share image:** create `assets/images/og-image.jpg` (1200x630). It is referenced by `og:image` but does not exist yet.
- [ ] **Placeholder images** (SVG stand-ins; replace with real photos, update the `src` and `alt`):
  - `assets/images/placeholder-hero.svg`: home page hero (caregiver with an older adult at home)
  - `assets/images/placeholder-about.svg`: home page intro and About page story
  - `assets/images/placeholder-aging-in-place.svg`: Services, "Aging in Place" section
  - `assets/images/placeholder-service-area.svg`: Contact page service-area map/graphic
- [ ] **Founder bio and credentials:** labeled placeholder block on `about.html` ("Meet the team"). Replace or remove.
- [ ] **Business hours:** placeholder on `contact.html`.
- [ ] **Service area details:** specific counties/cities placeholder on `contact.html`.
- [ ] **Privacy policy:** `privacy-policy.html` is a **draft and needs legal review**. Add the effective date.
- [ ] **Not included on purpose** (add only if true and verifiable): testimonials, statistics, years in business, awards, licenses/certifications, insurance or Medicaid acceptance, staff names, street address.
- [ ] **Pricing / FAQ answers:** several FAQ answers say "contact us for details". Update in `why-choose-us.html` once specifics are decided.

## Connecting the contact form to a real backend
The form (`contact.html`) is validated in `assets/js/forms.js`. On submit it currently opens a pre-filled `mailto:` to NEEMAHomeCare26@gmail.com.

Everything that sends data lives in one function, `submitForm(data)`, in `forms.js`. Replace its body with a `fetch` call and return the Promise. The file includes commented examples for:
- **Formspree:** POST JSON to `https://formspree.io/f/YOUR_FORM_ID`
- **Netlify Forms:** add `data-netlify="true"` and a hidden `form-name` input, POST URL-encoded data
- **Custom API:** POST to your endpoint

The success and error messages are shown automatically based on whether the Promise resolves or rejects. If you use a service, also update `privacy-policy.html` ("How the contact form works").

## Notes
- The home page includes one `application/ld+json` block (HomeAndCareService: name, phone, email only). This is data, not executable script.
- Fonts (Lora, Nunito Sans) load from Google Fonts. For full privacy, self-host them and update the policy.
- Pages were generated with consistent header/footer markup. If you change navigation, update it in every HTML file.

## Structure
```
index.html  about.html  services.html  why-choose-us.html  contact.html
privacy-policy.html  404.html  robots.txt  sitemap.xml
assets/css/   variables.css (all design tokens), base.css, components.css, pages.css, responsive.css
assets/js/    main.js (nav, header, smooth scroll, FAQ, year), forms.js, animations.js
assets/images/
```
